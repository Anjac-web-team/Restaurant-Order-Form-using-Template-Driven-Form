import { Component } from '@angular/core';
import { FormArray, FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-restaruntfoodorder',
  templateUrl: './restaruntfoodorder.component.html',
  styleUrls: ['./restaruntfoodorder.component.css']
})
export class RestaruntfoodorderComponent {

  orderForm: FormGroup;

  // Menu items with names and prices
  menuItems = [
    { name: 'Pizza', price: 10 },
    { name: 'Burger', price: 8 },
    { name: 'Pasta', price: 12 },
    { name: 'Salad', price: 6 },
    { name: 'Ice Cream', price: 5 },
  ];

  constructor(private fb: FormBuilder) {
    // Initialize the form
    this.orderForm = this.fb.group({
      customerName: ['', Validators.required],
      tableNumber: ['', Validators.required],
      items: this.fb.array([this.createItem()]), // Form array for ordered items
      deliveryOption: ['', Validators.required], // Radio button for delivery option
    });
  }

  // Create a new form group for an item
  createItem(): FormGroup {
    return this.fb.group({
      itemName: ['', Validators.required], // Dropdown for item name
      category: ['', Validators.required], // Dropdown for category
      quantity: [1, [Validators.required, Validators.min(1)]], // Quantity input
      price: [{ value: 0, disabled: true }], // Auto-calculated price (disabled to prevent manual input)
      cheese: [false], // Checkbox for cheese
      extraSpicy: [false], // Checkbox for extra spicy
    });
  }

  // Get form array for items
  get items(): FormArray {
    return this.orderForm.get('items') as FormArray;
  }

  // Add a new item to the form
  addItem(): void {
    this.items.push(this.createItem());
  }

  // Remove an item from the form
  removeItem(index: number): void {
    this.items.removeAt(index);
  }

  // Handle item selection and calculate price based on quantity and item price
  onItemSelect(index: number): void {
    const selectedItem = this.items.at(index);
    const itemName = selectedItem.get('itemName')?.value;
    const quantity = selectedItem.get('quantity')?.value || 1; // Default quantity to 1 if not set

    if (itemName) {
      const menuItem = this.menuItems.find(item => item.name === itemName);
      const pricePerItem = menuItem ? menuItem.price : 0;
      const totalPrice = pricePerItem * quantity;
      selectedItem.patchValue({ price: totalPrice });
    } else {
      selectedItem.patchValue({ price: 0 });
    }
  }

  // Recalculate price dynamically on quantity change
  onQuantityChange(index: number): void {
    this.onItemSelect(index);
  }

  // Calculate the total price of the order
  calculateTotal(): number {
    let total = 0;
    this.items.controls.forEach(item => {
      total += item.get('price')?.value || 0;
    });
    return total;
  }

  submitOrder(): void {
    if (this.orderForm.valid) {
      const orderDetails = this.orderForm.value;

      // Calculate the total order amount
      const totalAmount = this.calculateTotal();
  
      // Calculate GST (assuming 18% GST)
      const gstRate = 0.18;
      const gstAmount = totalAmount * gstRate;
      const grandTotal = totalAmount + gstAmount;
  
      // Open a new window for bill printing
      this.openBillWindow(orderDetails, totalAmount, gstAmount, grandTotal);
    } else {
      alert('Please complete the form correctly.');
      this.orderForm.markAllAsTouched();
    }
  }

  openBillWindow(orderDetails: any, totalAmount: number, gstAmount: number, grandTotal: number): void {
    window.open('', '_blank', 'width=600,height=800');

    if (true) {
      const billContent = `
        <html>
        <head>
          <title>Bill</title>
          <style>
            body { font-family: Arial, sans-serif; }
            .container { width: 100%; max-width: 600px; margin: auto; padding: 20px; }
            h2 { text-align: center; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            table, th, td { border: 1px solid black; }
            th, td { padding: 8px; text-align: left; }
            .totals { text-align: right; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <h2>Restaurant Bill</h2>
            <p><strong>Customer Name:</strong> ${orderDetails.customerName}</p>
            <p><strong>Table Number:</strong> ${orderDetails.tableNumber}</p>
            <table>
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Quantity</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                ${orderDetails.items.map((item: any) => `
                  <tr>
                    <td>${item.itemName}</td>
                    <td>${item.quantity}</td>
                    <td>$${item.price.toFixed(2)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            <div class="totals">
              <p><strong>Total Amount:</strong> $${totalAmount.toFixed(2)}</p>
              <p><strong>GST (18%):</strong> $${gstAmount.toFixed(2)}</p>
              <p><strong>Grand Total:</strong> $${grandTotal.toFixed(2)}</p>
            </div>
          </div>
          <script>
            window.print();
          </script>
        </body>
        </html>
      `;
      window.document.write(billContent);
      // billWindow.document.close();
    }
  }
}
