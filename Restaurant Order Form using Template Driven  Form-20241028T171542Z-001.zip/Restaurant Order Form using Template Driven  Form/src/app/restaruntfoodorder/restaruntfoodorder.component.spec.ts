import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaruntfoodorderComponent } from './restaruntfoodorder.component';

describe('RestaruntfoodorderComponent', () => {
  let component: RestaruntfoodorderComponent;
  let fixture: ComponentFixture<RestaruntfoodorderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RestaruntfoodorderComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RestaruntfoodorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
